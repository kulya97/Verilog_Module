The folder contains the documentation of UVM based VIP for APB-UART.
